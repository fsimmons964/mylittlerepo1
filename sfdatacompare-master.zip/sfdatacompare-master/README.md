# sfdatacompare
Compare data between selected objects and fields for two Salesforce Orgs.

This app is a Django app designed to run on Heroku.
